

export 'package:peliculas/widgets/card_swiper.dart';
export 'package:peliculas/widgets/casting_cards.dart';
export 'package:peliculas/widgets/movie_slider.dart';



