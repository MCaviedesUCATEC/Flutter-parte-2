package com.example.fl_components

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
