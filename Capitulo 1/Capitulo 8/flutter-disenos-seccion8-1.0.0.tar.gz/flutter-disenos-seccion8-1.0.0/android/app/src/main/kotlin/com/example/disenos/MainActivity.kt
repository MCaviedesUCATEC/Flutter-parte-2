package com.example.disenos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
