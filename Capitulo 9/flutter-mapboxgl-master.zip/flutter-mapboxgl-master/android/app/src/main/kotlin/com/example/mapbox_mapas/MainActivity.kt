package com.example.mapbox_mapas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
