# Peliculas

Este es el repositorio del proyecto de películas de mi curso de Flutter

https://fernando-herrera.com/#/home
